<?php
require_once 'config.php';

$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    handleMessage($db, getJsonInput());
} elseif ($method === 'GET') {
    if (isset($_GET['action']) && $_GET['action'] === 'poll') {
        pollMessages($db, intval($_GET['user_id']), intval($_GET['last_id'] ?? 0));
    } else {
        getChatHistory($db, $_GET['session_id']);
    }
}

function handleMessage($db, $data) {
    $sessionId = sanitize($data['session_id']);
    $userId = intval($data['user_id'] ?? 0);
    $message = sanitize($data['message']);
    $isUser = true;
    
    // Save message
    $sql = "INSERT INTO chat_messages 
            (session_id, user_id, message, is_user, created_at) 
            VALUES (:sess, :uid, :msg, :isuser, NOW())";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([
        ':sess' => $sessionId,
        ':uid' => $userId,
        ':msg' => $message,
        ':isuser' => $isUser ? 1 : 0
    ]);
    
    // Generate bot response
    $response = generateBotResponse($message);
    
    // Save bot response
    $sql = "INSERT INTO chat_messages 
            (session_id, user_id, message, is_user, created_at) 
            VALUES (:sess, 0, :msg, 0, NOW())";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([
        ':sess' => $sessionId,
        ':msg' => $response
    ]);
    
    jsonResponse(['response' => $response]);
}

function generateBotResponse($message) {
    $lower = strtolower($message);
    
    $responses = [
        'harga' => 'Untuk informasi harga, silakan cek di halaman produk atau bagian promo untuk diskon terbaru!',
        'pengiriman' => 'Kami mengirim ke seluruh Indonesia dengan estimasi 2-5 hari kerja. Gratis ongkir untuk pembelian di atas Rp 500.000!',
        'pembayaran' => 'Kami menerima transfer bank, kartu kredit, OVO, GoPay, DANA, dan COD.',
        'status' => 'Anda bisa cek status pesanan di menu "Pesanan Saya" dengan nomor pesanan Anda.',
        'retur' => 'Retur bisa dilakukan dalam 7 hari dengan syarat produk belum digunakan dan kemasan asli masih ada.',
        'jam' => 'Customer service kami tersedia Senin-Jumat 09.00-18.00 WIB.',
    ];
    
    foreach ($responses as $keyword => $response) {
        if (strpos($lower, $keyword) !== false) {
            return $response;
        }
    }
    
    $defaults = [
        'Terima kasih telah menghubungi kami! Ada yang bisa kami bantu?',
        'Silakan tanya tentang produk, pengiriman, atau pembayaran.',
        'Customer service kami siap membantu Anda 😊'
    ];
    
    return $defaults[array_rand($defaults)];
}

function pollMessages($db, $userId, $lastId) {
    // Check for new messages from admin
    $sql = "SELECT * FROM chat_messages 
            WHERE id > :lastid 
            AND user_id = 0 
            AND session_id IN (
                SELECT session_id FROM chat_messages 
                WHERE user_id = :uid
            )
            ORDER BY id ASC";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':lastid' => $lastId, ':uid' => $userId]);
    $messages = $stmt->fetchAll();
    
    jsonResponse(['messages' => $messages]);
}

function getChatHistory($db, $sessionId) {
    $sql = "SELECT * FROM chat_messages 
            WHERE session_id = :sess 
            ORDER BY created_at ASC";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':sess' => sanitize($sessionId)]);
    
    jsonResponse(['messages' => $stmt->fetchAll()]);
}

function getJsonInput() {
    return json_decode(file_get_contents('php://input'), true);
}
?>