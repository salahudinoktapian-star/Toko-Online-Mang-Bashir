<?php
require_once 'config.php';

$db = getDB();
$input = json_decode(file_get_contents('php://input'), true);
$action = $_GET['action'] ?? '';

switch ($action) {
    case 'sync':
        syncWishlist($db, $input);
        break;
    case 'get':
        getWishlist($db, intval($_GET['user_id']));
        break;
    case 'add':
        addToWishlist($db, $input);
        break;
    case 'remove':
        removeFromWishlist($db, $input);
        break;
    default:
        jsonResponse(['error' => 'Invalid action'], 400);
}

function syncWishlist($db, $data) {
    $userId = intval($data['user_id']);
    $wishlist = $data['wishlist'] ?? [];
    
    // Clear existing
    $stmt = $db->prepare("DELETE FROM wishlists WHERE user_id = :uid");
    $stmt->execute([':uid' => $userId]);
    
    // Insert new
    $sql = "INSERT INTO wishlists (user_id, product_id, created_at) 
            VALUES (:uid, :pid, NOW())";
    $stmt = $db->prepare($sql);
    
    foreach ($wishlist as $item) {
        $stmt->execute([
            ':uid' => $userId,
            ':pid' => intval($item['id'])
        ]);
    }
    
    jsonResponse(['success' => true]);
}

function getWishlist($db, $userId) {
    $sql = "SELECT p.* 
            FROM wishlists w
            JOIN products p ON w.product_id = p.id
            WHERE w.user_id = :uid AND p.status = 'active'";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':uid' => $userId]);
    
    jsonResponse(['wishlist' => $stmt->fetchAll()]);
}

function addToWishlist($db, $data) {
    $userId = intval($data['user_id']);
    $productId = intval($data['product_id']);
    
    $sql = "INSERT IGNORE INTO wishlists (user_id, product_id, created_at) 
            VALUES (:uid, :pid, NOW())";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':uid' => $userId, ':pid' => $productId]);
    
    jsonResponse(['success' => true]);
}

function removeFromWishlist($db, $data) {
    $userId = intval($data['user_id']);
    $productId = intval($data['product_id']);
    
    $sql = "DELETE FROM wishlists WHERE user_id = :uid AND product_id = :pid";
    $stmt = $db->prepare($sql);
    $stmt->execute([':uid' => $userId, ':pid' => $productId]);
    
    jsonResponse(['success' => true]);
}
?>