<?php
require_once 'config.php';

$db = getDB();
$action = $_GET['action'] ?? '';

switch ($action) {
    case 'add':
        addReview($db, getJsonInput());
        break;
    case 'get':
        getReviews($db, intval($_GET['product_id']));
        break;
    case 'moderate':
        moderateReview($db, getJsonInput());
        break;
    default:
        jsonResponse(['error' => 'Invalid action'], 400);
}

function addReview($db, $data) {
    $productId = intval($data['product_id']);
    $userId = intval($data['user_id']);
    $rating = intval($data['rating']);
    $comment = sanitize($data['comment']);
    
    // Validation
    if ($rating < 1 || $rating > 5) {
        jsonResponse(['error' => 'Rating harus 1-5'], 400);
    }
    
    // Check if user bought the product
    $sql = "SELECT o.id 
            FROM orders o
            JOIN order_items oi ON o.id = oi.order_id
            WHERE o.user_id = :uid 
            AND oi.product_id = :pid 
            AND o.status = 'delivered'";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':uid' => $userId, ':pid' => $productId]);
    
    if (!$stmt->fetch() && !isAdmin($userId)) {
        jsonResponse(['error' => 'Anda hanya bisa mengulas produk yang telah dibeli'], 403);
    }
    
    // Check if already reviewed
    $sql = "SELECT id FROM reviews WHERE product_id = :pid AND user_id = :uid";
    $stmt = $db->prepare($sql);
    $stmt->execute([':pid' => $productId, ':uid' => $userId]);
    
    if ($stmt->fetch()) {
        // Update existing review
        $sql = "UPDATE reviews SET 
                    rating = :rating,
                    comment = :comment,
                    updated_at = NOW()
                WHERE product_id = :pid AND user_id = :uid";
    } else {
        // Insert new review
        $sql = "INSERT INTO reviews 
                (product_id, user_id, rating, comment, created_at) 
                VALUES (:pid, :uid, :rating, :comment, NOW())";
    }
    
    $stmt = $db->prepare($sql);
    $stmt->execute([
        ':pid' => $productId,
        ':uid' => $userId,
        ':rating' => $rating,
        ':comment' => $comment
    ]);
    
    // Update product rating
    updateProductRating($db, $productId);
    
    jsonResponse(['success' => true]);
}

function getReviews($db, $productId) {
    $sql = "SELECT 
                r.*,
                u.name as user_name,
                u.avatar
            FROM reviews r
            JOIN users u ON r.user_id = u.id
            WHERE r.product_id = :pid
            ORDER BY r.created_at DESC";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':pid' => $productId]);
    $reviews = $stmt->fetchAll();
    
    // Get summary
    $sql = "SELECT 
                AVG(rating) as avg_rating,
                COUNT(*) as total_reviews,
                SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END) as five_star,
                SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END) as four_star,
                SUM(CASE WHEN rating = 3 THEN 1 ELSE 0 END) as three_star,
                SUM(CASE WHEN rating = 2 THEN 1 ELSE 0 END) as two_star,
                SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END) as one_star
            FROM reviews 
            WHERE product_id = :pid";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':pid' => $productId]);
    $summary = $stmt->fetch();
    
    jsonResponse([
        'reviews' => $reviews,
        'summary' => $summary
    ]);
}

function updateProductRating($db, $productId) {
    $sql = "UPDATE products p 
            SET rating = (
                SELECT AVG(rating) 
                FROM reviews 
                WHERE product_id = :pid
            )
            WHERE id = :pid";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':pid' => $productId]);
}

function moderateReview($db, $data) {
    // Admin only
    $reviewId = intval($data['review_id']);
    $status = $data['status']; // 'approved', 'rejected'
    
    $sql = "UPDATE reviews SET status = :status WHERE id = :id";
    $stmt = $db->prepare($sql);
    $stmt->execute([':status' => $status, ':id' => $reviewId]);
    
    jsonResponse(['success' => true]);
}

function isAdmin($userId) {
    // Check if user is admin
    return false; // Implement admin check
}

function getJsonInput() {
    return json_decode(file_get_contents('php://input'), true);
}
?>