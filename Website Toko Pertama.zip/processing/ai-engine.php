<?php
require_once 'config.php';

$db = getDB();
$action = $_GET['action'] ?? '';
$input = json_decode(file_get_contents('php://input'), true);

switch ($action) {
    case 'recommend':
        getRecommendations($db, intval($_GET['user_id']));
        break;
    case 'track':
        trackUserBehavior($db, $input);
        break;
    case 'track_view':
        trackProductView($db, $input);
        break;
    case 'search_suggest':
        getSearchSuggestions($db, $_GET['q']);
        break;
    case 'visual_search':
        handleVisualSearch($db, $input);
        break;
    case 'chatbot':
        handleChatbot($db, $input);
        break;
    case 'pricing':
        getPricingSuggestion($db, $input);
        break;
    default:
        jsonResponse(['error' => 'Invalid action'], 400);
}

function getRecommendations($db, $userId) {
    // Get user preferences
    $userPrefs = getUserPreferences($db, $userId);
    
    // Collaborative filtering: Find similar users
    $similarUsers = findSimilarUsers($db, $userId, $userPrefs);
    
    // Content-based filtering
    $contentBased = getContentBasedRecommendations($db, $userPrefs);
    
    // Trending products
    $trending = getTrendingProducts($db);
    
    // Combine recommendations
    $recommendations = mergeRecommendations($contentBased, $similarUsers, $trending);
    
    // Add explanation
    $recommendations = addExplanation($recommendations, $userPrefs);
    
    jsonResponse(['recommendations' => array_slice($recommendations, 0, 5)]);
}

function getUserPreferences($db, $userId) {
    // Get purchase history
    $sql = "SELECT p.category_id, p.brand_id, p.price
            FROM orders o
            JOIN order_items oi ON o.id = oi.order_id
            JOIN products p ON oi.product_id = p.id
            WHERE o.user_id = :uid AND o.status = 'delivered'
            ORDER BY o.created_at DESC
            LIMIT 20";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':uid' => $userId]);
    $purchases = $stmt->fetchAll();
    
    // Get browsing history
    $sql = "SELECT product_id FROM user_views 
            WHERE user_id = :uid 
            ORDER BY viewed_at DESC 
            LIMIT 50";
    $stmt = $db->prepare($sql);
    $stmt->execute([':uid' => $userId]);
    $views = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Calculate preferences
    $categories = [];
    $brands = [];
    $prices = [];
    
    foreach ($purchases as $p) {
        $categories[] = $p['category_id'];
        $brands[] = $p['brand_id'];
        $prices[] = $p['price'];
    }
    
    return [
        'categories' => array_count_values($categories),
        'brands' => array_count_values($brands),
        'avg_order_value' => $prices ? array_sum($prices) / count($prices) : 0,
        'recent_views' => $views,
        'purchase_history' => array_column($purchases, 'category_id')
    ];
}

function findSimilarUsers($db, $userId, $userPrefs) {
    // Find users with similar purchase patterns
    $sql = "SELECT o.user_id, COUNT(*) as common_products
            FROM orders o
            JOIN order_items oi ON o.id = oi.order_id
            WHERE oi.product_id IN (
                SELECT product_id FROM order_items oi2
                JOIN orders o2 ON oi2.order_id = o2.id
                WHERE o2.user_id = :uid
            )
            AND o.user_id != :uid
            GROUP BY o.user_id
            HAVING common_products >= 2
            ORDER BY common_products DESC
            LIMIT 10";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':uid' => $userId]);
    $similarUsers = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    if (empty($similarUsers)) {
        return [];
    }
    
    // Get products bought by similar users but not by current user
    $placeholders = implode(',', array_fill(0, count($similarUsers), '?'));
    $sql = "SELECT DISTINCT p.*, COUNT(*) as popularity
            FROM products p
            JOIN order_items oi ON p.id = oi.product_id
            JOIN orders o ON oi.order_id = o.id
            WHERE o.user_id IN ($placeholders)
            AND p.id NOT IN (
                SELECT product_id FROM order_items oi2
                JOIN orders o2 ON oi2.order_id = o2.id
                WHERE o2.user_id = ?
            )
            AND p.status = 'active'
            GROUP BY p.id
            ORDER BY popularity DESC
            LIMIT 10";
    
    $params = array_merge($similarUsers, [$userId]);
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    
    return $stmt->fetchAll();
}

function getContentBasedRecommendations($db, $userPrefs) {
    if (empty($userPrefs['categories'])) {
        return [];
    }
    
    // Get top categories
    arsort($userPrefs['categories']);
    $topCategories = array_slice(array_keys($userPrefs['categories']), 0, 3);
    
    $placeholders = implode(',', array_fill(0, count($topCategories), '?'));
    
    $sql = "SELECT p.*, 
            CASE 
                WHEN p.category_id IN ($placeholders) THEN 1 
                ELSE 0 
            END as category_match
            FROM products p
            WHERE p.status = 'active'
            AND (
                p.category_id IN ($placeholders)
                OR p.brand_id IN (" . implode(',', array_fill(0, count($userPrefs['brands']), '?')) . ")
            )
            AND p.id NOT IN (" . implode(',', array_fill(0, count($userPrefs['recent_views']), '?')) . ")
            ORDER BY category_match DESC, p.rating DESC
            LIMIT 15";
    
    $params = array_merge($topCategories, $topCategories, array_keys($userPrefs['brands']), $userPrefs['recent_views']);
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    
    return $stmt->fetchAll();
}

function getTrendingProducts($db) {
    $sql = "SELECT p.*, COUNT(oi.id) as recent_sales
            FROM products p
            JOIN order_items oi ON p.id = oi.product_id
            JOIN orders o ON oi.order_id = o.id
            WHERE o.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAYS)
            AND p.status = 'active'
            GROUP BY p.id
            ORDER BY recent_sales DESC
            LIMIT 10";
    
    $stmt = $db->query($sql);
    return $stmt->fetchAll();
}

function mergeRecommendations($content, $collaborative, $trending) {
    $scores = [];
    $products = [];
    
    // Score content-based (weight: 0.5)
    foreach ($content as $i => $p) {
        $id = $p['id'];
        $scores[$id] = ($scores[$id] ?? 0) + (0.5 * (1 - $i * 0.05));
        $products[$id] = $p;
    }
    
    // Score collaborative (weight: 0.3)
    foreach ($collaborative as $i => $p) {
        $id = $p['id'];
        $scores[$id] = ($scores[$id] ?? 0) + (0.3 * (1 - $i * 0.05));
        $products[$id] = $p;
    }
    
    // Score trending (weight: 0.2)
    foreach ($trending as $i => $p) {
        $id = $p['id'];
        $scores[$id] = ($scores[$id] ?? 0) + (0.2 * (1 - $i * 0.05));
        $products[$id] = $p;
    }
    
    arsort($scores);
    
    $result = [];
    foreach (array_keys($scores) as $id) {
        $result[] = $products[$id];
    }
    
    return $result;
}

function addExplanation($recommendations, $userPrefs) {
    $result = [];
    
    foreach ($recommendations as $product) {
        $reason = '';
        
        if (isset($userPrefs['categories'][$product['category_id']])) {
            $reason = 'Berdasarkan kategori favorit Anda';
        } elseif (isset($userPrefs['brands'][$product['brand_id']])) {
            $reason = 'Berdasarkan merek yang sering Anda beli';
        } else {
            $reason = 'Populer di kalangan pembeli serupa';
        }
        
        $result[] = [
            'product' => $product,
            'reason' => $reason,
            'score' => rand(85, 99) / 100 // Confidence score
        ];
    }
    
    return $result;
}

function trackUserBehavior($db, $data) {
    $sql = "INSERT INTO user_behavior_logs 
            (user_id, action, data, session_context, created_at) 
            VALUES (:uid, :action, :data, :ctx, NOW())";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([
        ':uid' => intval($data['user_id']),
        ':action' => sanitize($data['action']),
        ':data' => json_encode($data['data']),
        ':ctx' => json_encode($data['session_context'] ?? [])
    ]);
    
    jsonResponse(['success' => true]);
}

function trackProductView($db, $data) {
    $sql = "INSERT INTO user_views (user_id, product_id, viewed_at) 
            VALUES (:uid, :pid, NOW())
            ON DUPLICATE KEY UPDATE viewed_at = NOW()";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([
        ':uid' => intval($data['user_id']),
        ':pid' => intval($data['product_id'])
    ]);
    
    jsonResponse(['success' => true]);
}

function getSearchSuggestions($db, $query) {
    $query = sanitize($query);
    
    // Product suggestions
    $sql = "SELECT name as text, 'product' as type, 0.9 as confidence
            FROM products 
            WHERE name LIKE :q AND status = 'active'
            LIMIT 3";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':q' => "%$query%"]);
    $products = $stmt->fetchAll();
    
    // Category suggestions
    $sql = "SELECT name as text, 'category' as type, 0.8 as confidence
            FROM categories 
            WHERE name LIKE :q
            LIMIT 2";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':q' => "%$query%"]);
    $categories = $stmt->fetchAll();
    
    // Trending searches (mock)
    $trending = [
        ['text' => 'iPhone 15', 'type' => 'trending', 'confidence' => 0.7],
        ['text' => 'Sepatu Sneakers', 'type' => 'trending', 'confidence' => 0.7]
    ];
    
    $suggestions = array_merge($products, $categories, $trending);
    
    jsonResponse(['suggestions' => $suggestions]);
}

function handleVisualSearch($db, $input) {
    // Integration with image recognition API (Google Vision, AWS Rekognition, etc.)
    // For demo, return random products from similar category
    
    $detectedCategory = rand(1, 5); // Mock detection
    
    $sql = "SELECT * FROM products 
            WHERE category_id = :cat AND status = 'active' 
            LIMIT 5";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':cat' => $detectedCategory]);
    
    jsonResponse([
        'similar_products' => $stmt->fetchAll(),
        'detected_objects' => ['electronic', 'gadget']
    ]);
}

function handleChatbot($db, $input) {
    $message = strtolower(sanitize($input['message']));
    $context = $input['context'] ?? [];
    
    // Simple intent classification
    $intents = [
        'price' => ['harga', 'mahal', 'murah', 'diskon', 'promo'],
        'shipping' => ['kirim', 'pengiriman', 'ongkir', 'lama', 'cepat'],
        'stock' => ['stock', 'tersedia', 'habis', 'ready'],
        'payment' => ['bayar', 'transfer', 'cod', 'kartu'],
        'return' => ['return', 'retur', 'kembali', 'refund']
    ];
    
    $detectedIntent = 'general';
    foreach ($intents as $intent => $keywords) {
        foreach ($keywords as $keyword) {
            if (strpos($message, $keyword) !== false) {
                $detectedIntent = $intent;
                break 2;
            }
        }
    }
    
    // Generate response based on intent
    $responses = [
        'price' => 'Anda bisa melihat harga terbaru di halaman produk. Saat ini ada diskon 10% untuk pengguna baru!',
        'shipping' => 'Kami bekerjasama dengan JNE, J&T, dan SiCepat. Gratis ongkir untuk pembelian di atas Rp 500.000.',
        'stock' => 'Stok kami terupdate real-time. Jika bisa ditambah ke keranjang, berarti tersedia ya!',
        'payment' => 'Kami menerima pembayaran via transfer bank, kartu kredit, OVO, GoPay, DANA, dan COD.',
        'return' => 'Anda bisa retur dalam 7 hari jika produk cacat atau tidak sesuai. Syarat: kemasan asli masih ada.',
        'general' => 'Terima kasih pertanyaannya! Customer service kami akan segera membantu lebih lanjut.'
    ];
    
    // Check if asking about specific product
    if (preg_match('/produk (\d+)/', $message, $matches)) {
        $productId = $matches[1];
        $product = getProductQuick($db, $productId);
        if ($product) {
            $response = "Produk {$product['name']} harganya Rp " . number_format($product['price']) . 
                       ". Stok tersedia: {$product['stock']} unit.";
        }
    } else {
        $response = $responses[$detectedIntent];
    }
    
    jsonResponse([
        'response' => $response,
        'intent' => $detectedIntent,
        'confidence' => 0.85
    ]);
}

function getProductQuick($db, $id) {
    $sql = "SELECT name, price, stock FROM products WHERE id = :id";
    $stmt = $db->prepare($sql);
    $stmt->execute([':id' => $id]);
    return $stmt->fetch();
}

function getPricingSuggestion($db, $input) {
    $categoryId = intval($input['category_id']);
    $costPrice = floatval($input['cost_price']);
    
    // Get market data
    $sql = "SELECT AVG(price) as avg_price, MIN(price) as min_price, MAX(price) as max_price
            FROM products 
            WHERE category_id = :cat AND status = 'active'";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':cat' => $categoryId]);
    $market = $stmt->fetch();
    
    // AI pricing algorithm
    $suggestedPrice = max(
        $costPrice * 1.25, // Minimum 25% margin
        $market['avg_price'] * 0.95 // Slightly below average
    );
    
    jsonResponse([
        'suggested_price' => round($suggestedPrice, -3), // Round to thousands
        'market_data' => $market,
        'confidence' => 0.82,
        'factors' => [
            'competition' => '5% below market average',
            'margin' => round((($suggestedPrice - $costPrice) / $suggestedPrice) * 100, 1) . '%'
        ]
    ]);
}
?>