<?php
require_once 'config.php';

$db = getDB();
$action = $_GET['action'] ?? '';

switch ($action) {
    case 'sync':
        syncInventory($db, getJsonInput());
        break;
    case 'check':
        checkStock($db, intval($_GET['product_id']));
        break;
    case 'update':
        updateStock($db, getJsonInput());
        break;
    case 'alerts':
        getLowStockAlerts($db);
        break;
    case 'forecast':
        getDemandForecast($db, intval($_GET['product_id']));
        break;
    default:
        jsonResponse(['error' => 'Invalid action'], 400);
}

function syncInventory($db, $data) {
    // Real-time sync with warehouse systems
    $updates = $data['updates'] ?? [];
    
    $db->beginTransaction();
    
    $sql = "UPDATE products SET 
                stock = :stock,
                reserved_stock = :reserved,
                updated_at = NOW()
            WHERE id = :id";
    
    $stmt = $db->prepare($sql);
    
    foreach ($updates as $update) {
        $stmt->execute([
            ':stock' => intval($update['stock']),
            ':reserved' => intval($update['reserved'] ?? 0),
            ':id' => intval($update['product_id'])
        ]);
        
        // Log change
        logInventoryChange($db, $update['product_id'], $update['stock'], 'sync');
    }
    
    $db->commit();
    
    jsonResponse(['success' => true, 'synced' => count($updates)]);
}

function checkStock($db, $productId) {
    $sql = "SELECT stock, reserved_stock, 
            (stock - reserved_stock) as available_stock
            FROM products 
            WHERE id = :id";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':id' => $productId]);
    $stock = $stmt->fetch();
    
    if (!$stock) {
        jsonResponse(['error' => 'Product not found'], 404);
    }
    
    jsonResponse($stock);
}

function updateStock($db, $data) {
    $productId = intval($data['product_id']);
    $quantity = intval($data['quantity']);
    $type = $data['type']; // 'add', 'subtract', 'set'
    $reason = sanitize($data['reason'] ?? 'manual_update');
    
    $sql = "SELECT stock FROM products WHERE id = :id FOR UPDATE";
    $stmt = $db->prepare($sql);
    $stmt->execute([':id' => $productId]);
    $current = $stmt->fetchColumn();
    
    $newStock = match($type) {
        'add' => $current + $quantity,
        'subtract' => max(0, $current - $quantity),
        'set' => $quantity,
        default => $current
    };
    
    $sql = "UPDATE products SET stock = :stock, updated_at = NOW() WHERE id = :id";
    $stmt = $db->prepare($sql);
    $stmt->execute([':stock' => $newStock, ':id' => $productId]);
    
    logInventoryChange($db, $productId, $quantity, $type, $reason);
    
    // Check if auto-reorder needed
    if ($newStock <= 10) {
        triggerAutoReorder($db, $productId, $newStock);
    }
    
    jsonResponse(['success' => true, 'new_stock' => $newStock]);
}

function logInventoryChange($db, $productId, $quantity, $type, $reason = '') {
    $sql = "INSERT INTO inventory_logs 
            (product_id, quantity_change, type, reason, created_at) 
            VALUES (:pid, :qty, :type, :reason, NOW())";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([
        ':pid' => $productId,
        ':qty' => $quantity,
        ':type' => $type,
        ':reason' => $reason
    ]);
}

function triggerAutoReorder($db, $productId, $currentStock) {
    // Check if reorder already triggered
    $sql = "SELECT id FROM auto_reorders 
            WHERE product_id = :pid AND status = 'pending'";
    $stmt = $db->prepare($sql);
    $stmt->execute([':pid' => $productId]);
    
    if ($stmt->fetch()) {
        return; // Already pending
    }
    
    // Calculate reorder quantity
    $sql = "SELECT AVG(quantity) as avg_sales 
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.id
            WHERE oi.product_id = :pid 
            AND o.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':pid' => $productId]);
    $avgSales = $stmt->fetchColumn() ?: 10;
    
    $reorderQty = ceil($avgSales * 2); // 2 months stock
    
    // Create reorder request
    $sql = "INSERT INTO auto_reorders 
            (product_id, current_stock, suggested_qty, status, created_at) 
            VALUES (:pid, :stock, :qty, 'pending', NOW())";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([
        ':pid' => $productId,
        ':stock' => $currentStock,
        ':qty' => $reorderQty
    ]);
    
    // Notify vendor/admin
    notifyReorder($db, $productId, $reorderQty);
}

function getLowStockAlerts($db) {
    $sql = "SELECT p.id, p.name, p.stock, v.name as vendor_name, v.email
            FROM products p
            JOIN vendors v ON p.vendor_id = v.id
            WHERE p.stock <= 10 AND p.status = 'active'
            ORDER BY p.stock ASC";
    
    $stmt = $db->query($sql);
    $alerts = $stmt->fetchAll();
    
    jsonResponse(['alerts' => $alerts]);
}

function getDemandForecast($db, $productId) {
    // Simple moving average forecast
    $sql = "SELECT 
                DATE_FORMAT(o.created_at, '%Y-%m') as month,
                SUM(oi.quantity) as sales
            FROM orders o
            JOIN order_items oi ON o.id = oi.order_id
            WHERE oi.product_id = :pid
            AND o.created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
            GROUP BY month
            ORDER BY month";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':pid' => $productId]);
    $history = $stmt->fetchAll();
    
    if (count($history) < 3) {
        jsonResponse(['error' => 'Insufficient data'], 400);
    }
    
    // Calculate trend
    $sales = array_column($history, 'sales');
    $avg = array_sum($sales) / count($sales);
    $trend = ($sales[count($sales)-1] - $sales[0]) / count($sales);
    
    // Forecast next 3 months
    $forecast = [];
    for ($i = 1; $i <= 3; $i++) {
        $forecast[] = [
            'month' => date('Y-m', strtotime("+ $i months")),
            'predicted_sales' => round(max(0, $avg + ($trend * $i))),
            'confidence' => max(0.5, 0.9 - ($i * 0.1))
        ];
    }
    
    jsonResponse([
        'history' => $history,
        'forecast' => $forecast,
        'trend' => $trend > 0 ? 'increasing' : ($trend < 0 ? 'decreasing' : 'stable')
    ]);
}

function notifyReorder($db, $productId, $quantity) {
    // Implementation for email/notification
    error_log("Auto-reorder triggered: Product $productId, Qty: $quantity");
}

function getJsonInput() {
    return json_decode(file_get_contents('php://input'), true);
}
?>