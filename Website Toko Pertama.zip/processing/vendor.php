<?php
require_once 'config.php';

$db = getDB();
$action = $_GET['action'] ?? '';

switch ($action) {
    case 'list':
        listVendors($db);
        break;
    case 'register':
        registerVendor($db, getJsonInput());
        break;
    case 'dashboard':
        getVendorDashboard($db, intval($_GET['vendor_id']));
        break;
    case 'products':
        getVendorProducts($db, intval($_GET['vendor_id']));
        break;
    case 'orders':
        getVendorOrders($db, intval($_GET['vendor_id']));
        break;
    case 'stats':
        getVendorStats($db, intval($_GET['vendor_id']));
        break;
    default:
        jsonResponse(['error' => 'Invalid action'], 400);
}

function listVendors($db) {
    $sql = "SELECT 
                v.*,
                COUNT(DISTINCT p.id) as product_count,
                COALESCE(AVG(r.rating), 0) as rating,
                COUNT(DISTINCT o.id) as total_orders
            FROM vendors v
            LEFT JOIN products p ON v.id = p.vendor_id AND p.status = 'active'
            LEFT JOIN reviews r ON p.id = r.product_id
            LEFT JOIN orders o ON o.status != 'cancelled'
            LEFT JOIN order_items oi ON o.id = oi.order_id AND oi.product_id = p.id
            WHERE v.status = 'active'
            GROUP BY v.id
            ORDER BY rating DESC
            LIMIT 20";
    
    $stmt = $db->query($sql);
    $vendors = $stmt->fetchAll();
    
    foreach ($vendors as &$vendor) {
        $vendor['logo'] = $vendor['logo'] ?: 'https://via.placeholder.com/150/6366f1/ffffff?text=' . urlencode($vendor['name']);
    }
    
    jsonResponse(['vendors' => $vendors]);
}

function registerVendor($db, $data) {
    // Validation
    if (empty($data['name']) || empty($data['email']) || empty($data['phone'])) {
        jsonResponse(['error' => 'Required fields missing'], 400);
    }
    
    // Check if email exists
    $stmt = $db->prepare("SELECT id FROM vendors WHERE email = :email");
    $stmt->execute([':email' => sanitize($data['email'])]);
    if ($stmt->fetch()) {
        jsonResponse(['error' => 'Email already registered'], 400);
    }
    
    $sql = "INSERT INTO vendors (
                name, email, phone, description, 
                address, status, created_at
            ) VALUES (
                :name, :email, :phone, :desc,
                :addr, 'pending', NOW()
            )";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([
        ':name' => sanitize($data['name']),
        ':email' => sanitize($data['email']),
        ':phone' => sanitize($data['phone']),
        ':desc' => sanitize($data['description'] ?? ''),
        ':addr' => sanitize($data['address'] ?? '')
    ]);
    
    $vendorId = $db->lastInsertId();
    
    // Send notification to admin for approval
    notifyAdminNewVendor($vendorId, $data['name']);
    
    jsonResponse([
        'success' => true,
        'vendor_id' => $vendorId,
        'message' => 'Pendaftaran berhasil, menunggu persetujuan admin'
    ]);
}

function getVendorDashboard($db, $vendorId) {
    // Revenue stats
    $sql = "SELECT 
                COALESCE(SUM(o.total), 0) as total_revenue,
                COUNT(DISTINCT o.id) as total_orders,
                COUNT(DISTINCT o.user_id) as unique_customers
            FROM orders o
            JOIN order_items oi ON o.id = oi.order_id
            JOIN products p ON oi.product_id = p.id
            WHERE p.vendor_id = :vid AND o.status = 'delivered'";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':vid' => $vendorId]);
    $stats = $stmt->fetch();
    
    // Monthly revenue
    $sql = "SELECT 
                DATE_FORMAT(o.created_at, '%Y-%m') as month,
                SUM(o.total) as revenue
            FROM orders o
            JOIN order_items oi ON o.id = oi.order_id
            JOIN products p ON oi.product_id = p.id
            WHERE p.vendor_id = :vid 
            AND o.created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
            GROUP BY month
            ORDER BY month";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':vid' => $vendorId]);
    $monthly = $stmt->fetchAll();
    
    // Recent orders
    $sql = "SELECT o.*, oi.quantity, p.name as product_name
            FROM orders o
            JOIN order_items oi ON o.id = oi.order_id
            JOIN products p ON oi.product_id = p.id
            WHERE p.vendor_id = :vid
            ORDER BY o.created_at DESC
            LIMIT 5";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':vid' => $vendorId]);
    $recentOrders = $stmt->fetchAll();
    
    jsonResponse([
        'stats' => $stats,
        'monthly_revenue' => $monthly,
        'recent_orders' => $recentOrders
    ]);
}

function getVendorProducts($db, $vendorId) {
    $sql = "SELECT p.*, 
            COALESCE(AVG(r.rating), 0) as rating,
            COUNT(r.id) as review_count
            FROM products p
            LEFT JOIN reviews r ON p.id = r.product_id
            WHERE p.vendor_id = :vid
            GROUP BY p.id
            ORDER BY p.created_at DESC";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':vid' => $vendorId]);
    $products = $stmt->fetchAll();
    
    jsonResponse(['products' => $products]);
}

function getVendorOrders($db, $vendorId) {
    $status = $_GET['status'] ?? 'all';
    
    $sql = "SELECT o.*, oi.quantity, oi.price as item_price, p.name as product_name
            FROM orders o
            JOIN order_items oi ON o.id = oi.order_id
            JOIN products p ON oi.product_id = p.id
            WHERE p.vendor_id = :vid";
    
    if ($status !== 'all') {
        $sql .= " AND o.status = :status";
    }
    
    $sql .= " ORDER BY o.created_at DESC";
    
    $stmt = $db->prepare($sql);
    $params = [':vid' => $vendorId];
    if ($status !== 'all') {
        $params[':status'] = $status;
    }
    $stmt->execute($params);
    
    jsonResponse(['orders' => $stmt->fetchAll()]);
}

function getVendorStats($db, $vendorId) {
    // Product performance
    $sql = "SELECT 
                p.name,
                SUM(oi.quantity) as sold,
                SUM(oi.quantity * oi.price) as revenue
            FROM products p
            LEFT JOIN order_items oi ON p.id = oi.product_id
            LEFT JOIN orders o ON oi.order_id = o.id AND o.status = 'delivered'
            WHERE p.vendor_id = :vid
            GROUP BY p.id
            ORDER BY sold DESC
            LIMIT 10";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':vid' => $vendorId]);
    $topProducts = $stmt->fetchAll();
    
    // Stock alerts
    $sql = "SELECT name, stock FROM products 
            WHERE vendor_id = :vid AND stock <= 5 AND status = 'active'";
    $stmt = $db->prepare($sql);
    $stmt->execute([':vid' => $vendorId]);
    $lowStock = $stmt->fetchAll();
    
    jsonResponse([
        'top_products' => $topProducts,
        'low_stock_alerts' => $lowStock
    ]);
}

function notifyAdminNewVendor($vendorId, $vendorName) {
    // Implementation for admin notification
    error_log("New vendor registration pending approval: $vendorName (ID: $vendorId)");
}

function getJsonInput() {
    return json_decode(file_get_contents('php://input'), true);
}
?>